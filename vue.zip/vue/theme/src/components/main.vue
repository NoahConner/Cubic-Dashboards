<template>
    <router-view></router-view>
</template>
<script>
import  {default_layout} from  '../constants/config'
export default {
  name: 'mainpage', 
}
</script>
