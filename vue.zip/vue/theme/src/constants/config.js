
export const defaultLocale = "en";
export const localeOptions=[
    {id:'en',name:'English',icon:'flag-icon-us'},
    {id:'es',name:'Español',icon:'flag-icon-es'},
];
