<template>
  <div>
    <Breadcrumbs main="Ecommerce" title="Wishlist" />
    <!-- Container-fluid starts-->
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-12">
          <px-card title="Wishlist" :actions="false">
            <div slot="with-padding">
              <div class="row">
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-6.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-5.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-4.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-3.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-2.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-1.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-1.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-6.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-5.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-4.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-3.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-3.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-2.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-6.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart</a
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-md-6">
                  <div class="prooduct-details-box">
                    <div class="media">
                      <img
                        class="align-self-center img-fluid img-60"
                        src="../../assets/images/ecommerce/product-table-5.png"
                        alt="#"
                      />
                      <div class="media-body ml-3">
                        <div class="product-name">
                          <h6><a href="#">Fancy Women's Cotton</a></h6>
                        </div>
                        <div class="rating">
                          <i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i><i class="fa fa-star"></i
                          ><i class="fa fa-star"></i>
                        </div>
                        <div class="price d-flex">
                          <div class="text-muted mr-2">Price</div>
                          : 210$
                        </div>
                        <div class="avaiabilty">
                          <div class="text-success">In stock</div>
                        </div>
                        <a class="btn btn-primary btn-xs" href="#"
                          >Move to Cart
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </px-card>
        </div>
      </div>
      <!-- Container-fluid Ends-->
    </div>
    <!-- Container-fluid Ends-->
  </div>
</template>