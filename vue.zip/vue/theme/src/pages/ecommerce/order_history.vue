<template>
  <div>
    <Breadcrumbs main="Ecommerce" title="Order Details"/>
      <!-- Container-fluid starts-->
      <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <px-card title="New Orders" :actions="false">
                  <div slot="with-padding">
                    <div class="row">
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box">                                 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-6.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-5.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-4.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-3.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-2.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-1.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-1.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box">                                 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-6.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-5.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-primary btn-xs" href="#">Processing</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </px-card>

                <px-card title="Shipped Orders" :actions="false">
                  <div slot="with-padding">
                    <div class="row">
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box">                                 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-6.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-5.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-4.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-3.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-3.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-2.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box">                                 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-6.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-5.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x">   </i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-1.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-success btn-xs" href="#">Shipped</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </px-card>

                <px-card title="Cancelled Orders" :actions="false">
                  <div slot="with-padding">
                    <div class="row">
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box">                                 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-6.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-5.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-4.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-3.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-2.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-1.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-1.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box">                                 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-6.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6">
                        <div class="prooduct-details-box"> 
                          <div class="media"><img class="align-self-center img-fluid img-60" src="../../assets/images/ecommerce/product-table-5.png" alt="#">
                            <div class="media-body ml-3">
                              <div class="product-name">
                                <h6><a href="#">Fancy Women's Cotton</a></h6>
                              </div>
                              <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                              <div class="price d-flex"> 
                                <div class="text-muted mr-2">Price</div>: 210$
                              </div>
                              <div class="avaiabilty">
                                <div class="text-success">In stock</div>
                              </div><a class="btn btn-danger btn-xs" href="#">Cancelled</a><i class="close" data-feather="x"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </px-card>
              </div>
              <div class="col-sm-12">
                <px-card title="Datatable order history" :actions="false">
                  <div slot="with-padding">
                    <div class="order-history">
                      <table class="table table-bordernone display" id="basic-1">
                        <thead>
                          <tr>
                            <th scope="col">Prdouct</th>
                            <th scope="col">Prdouct name</th>
                            <th scope="col">Size</th>
                            <th scope="col">Color</th>
                            <th scope="col">Article number</th>
                            <th scope="col">Units</th>
                            <th scope="col">Price</th>
                            <th scope="col"><i class="fa fa-angle-down"></i></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/1.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Long Top</a>
                                <div class="order-process"><span class="order-process-circle"></span>Processing</div>
                              </div>
                            </td>
                            <td>M</td>
                            <td>Lavander</td>
                            <td>4215738</td>
                            <td>1</td>
                            <td>$21</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/13.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Fancy watch</a>
                                <div class="order-process"><span class="order-process-circle"></span>Processing</div>
                              </div>
                            </td>
                            <td>35mm</td>
                            <td>Blue</td>
                            <td>5476182</td>
                            <td>1</td>
                            <td>$10</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/4.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Man shoes</a>
                                <div class="order-process"><span class="order-process-circle"></span>Processing</div>
                              </div>
                            </td>
                            <td>8</td>
                            <td>Black & white</td>
                            <td>1756457</td>
                            <td>1</td>
                            <td>$18</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/10.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Ledis side bag</a>
                                <div class="order-process"><span class="order-process-circle shipped-order"></span>Shipped</div>
                              </div>
                            </td>
                            <td>22cm x 18cm</td>
                            <td>Brown</td>
                            <td>7451725</td>
                            <td>1</td>
                            <td>$13</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/12.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Ledis Slipper</a>
                                <div class="order-process"><span class="order-process-circle shipped-order"></span>Shipped</div>
                              </div>
                            </td>
                            <td>6</td>
                            <td>Brown & white</td>
                            <td>4127421</td>
                            <td>1</td>
                            <td>$6</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/3.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Fancy ledis Jacket</a>
                                <div class="order-process"><span class="order-process-circle shipped-order"></span>Shipped</div>
                              </div>
                            </td>
                            <td>Xl</td>
                            <td>Light gray</td>
                            <td>3581714</td>
                            <td>1</td>
                            <td>$24</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/2.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Ledis Handbag</a>
                                <div class="order-process"><span class="order-process-circle shipped-order"></span>Shipped</div>
                              </div>
                            </td>
                            <td>25cm x 20cm</td>
                            <td>Black</td>
                            <td>6748142</td>
                            <td>1</td>
                            <td>$14</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/15.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Iphone6 mobile</a>
                                <div class="order-process"><span class="order-process-circle cancel-order"></span>Cancelled</div>
                              </div>
                            </td>
                            <td>10cm x 15cm</td>
                            <td>Black</td>
                            <td>5748214</td>
                            <td>1</td>
                            <td>$25</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/14.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Watch</a>
                                <div class="order-process"><span class="order-process-circle cancel-order"></span>Cancelled</div>
                              </div>
                            </td>
                            <td>27mm</td>
                            <td>Brown</td>
                            <td>2471254</td>
                            <td>1</td>
                            <td>$12</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                          <tr>
                            <td><img class="img-fluid img-30" src="../../assets/images/product/11.png" alt="#"></td>
                            <td>
                              <div class="product-name"><a href="#">Slipper</a>
                                <div class="order-process"><span class="order-process-circle cancel-order"></span>Cancelled</div>
                              </div>
                            </td>
                            <td>6</td>
                            <td>Blue</td>
                            <td>8475112</td>
                            <td>1</td>
                            <td>$6</td>
                            <td><i data-feather="more-vertical"></i></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </px-card>
              </div>
            </div>
          </div>
      <!-- Container-fluid Ends-->
  </div>
</template>

<script>
  import { mapState } from "vuex";
  export default {
    data(){
      return {
      }
    },
    computed: {
      ...mapState({
        orederhistory: state => state.common.orederhistory
      })
    },
    methods:{
      getImgUrl(path) {
        return require('@/assets/images/'+path)
      },
    }
  }
</script>