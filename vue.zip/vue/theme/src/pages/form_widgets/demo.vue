<template>
    <div>
        <Breadcrumbs title="Select2"/>
        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                      <h5 class="card-title">Select-2</h5>
                    </div>
                    <div class="card-body">
                      <div class="mb-2">
                        <div class="col-form-label">Default Placeholder</div>
                      </div>
                    </div>
                </div>
              </div>               
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>
</template>

<script>
export default {
}
</script>