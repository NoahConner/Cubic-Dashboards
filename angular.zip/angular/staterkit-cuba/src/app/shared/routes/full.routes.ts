import { Routes } from '@angular/router';

export const full: Routes = [
];
