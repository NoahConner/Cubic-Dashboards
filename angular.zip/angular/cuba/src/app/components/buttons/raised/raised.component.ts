import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raised',
  templateUrl: './raised.component.html',
  styleUrls: ['./raised.component.scss']
})
export class RaisedComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
