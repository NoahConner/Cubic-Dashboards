import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-form',
  templateUrl: './default-form.component.html',
  styleUrls: ['./default-form.component.scss']
})
export class DefaultFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
