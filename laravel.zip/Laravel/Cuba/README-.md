# Cuba
Cuba Admin Template



Locallization- Language changes
https://stackoverflow.com/questions/41265880/laravel-change-locale-not-working
